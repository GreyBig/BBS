<?php
// 处理add_bbs_plate传过来的数据

$server = "localhost";
$username = "root";
$password = "root";
$bbs_database = "bbs";
$bbs_table = "tb_bbs_plate";

if($_POST["name"] == "")
{
    exit;
}
$name = $_POST["name"];
$subject = $_POST["subject"];
$description = $_POST["description"];
// 创建时间
date_default_timezone_set('PRC');
$create_time = date('Y-n-j H:i:s',time());

// 连接数据库
$conn = mysqli_connect($server,$username,$password,$bbs_database);
if(!$conn) {
    die('Could not connect: ' . mysqli_error($conn));
} else {
    echo 'Success';
}

mysqli_set_charset($conn, "utf8");
$str = "INSERT INTO ".$bbs_table." VALUES (0,'$subject','$name', '$description', '$create_time')";
//var_dump($str);die;
$ret = mysqli_query($conn, $str);

if($ret == false) {
    echo "query error".mysqli_error($conn);
    header("refresh:2;url=add_bbs_plate.php");
} else {
    echo "<script> window.alert(\"插入数据成功！\");location.href=\"add_bbs_plate.php\"</script>";
}
