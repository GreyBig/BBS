<?php



/**
 * 删除文件
 * @param $dir
 */
//function rm_file($dir)
//{
//    if(is_dir($dir) == false)
//    {
//        echo $dir."is a file";
//        exit();
//    }
//
//    $ret = rmdir($dir);
//
//    if($ret == 1)
//    {
//        echo "rm dir success";
//    }
//
//}
//rm_file($_GET["dir"]);